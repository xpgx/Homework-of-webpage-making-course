package net.fuzui.beans;

public class StuSelectResult implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String classr;
	private String coursetime;
	private String courseweek;
	private String cname;
	private String classroom;
	private String credits;
	private String period;
	private String tname;
	public String getClassr() {
		return classr;
	}
	public void setClassr(String classr) {
		this.classr = classr;
	}
	public String getCoursetime() {
		return coursetime;
	}
	public void setCoursetime(String coursetime) {
		this.coursetime = coursetime;
	}
	public String getCourseweek() {
		return courseweek;
	}
	public void setCourseweek(String courseweek) {
		this.courseweek = courseweek;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getClassroom() {
		return classroom;
	}
	public void setClassroom(String classroom) {
		this.classroom = classroom;
	}
	public String getCredits() {
		return credits;
	}
	public void setCredits(String credits) {
		this.credits = credits;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	
	
	
	
	
	
}
